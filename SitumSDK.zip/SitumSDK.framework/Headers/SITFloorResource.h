//
//  SITFloorResource.h
//  SitumSDK
//
//  Created by A Barros on 2/3/17.
//  Copyright © 2017 Situm. All rights reserved.
//

#import "SITBuildingResource.h"

@interface SITFloorResource : SITBuildingResource

@property (nonatomic, strong) NSString *floorIdentifier;

@end
