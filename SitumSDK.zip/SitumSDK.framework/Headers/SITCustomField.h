//
//  SITPOICustomField.h
//  SitumSDK
//
//  Created by A Barros on 10/6/16.
//  Copyright © 2016 Situm. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SITCustomField : NSObject

@property (nonatomic, strong) NSString *key;
@property (nonatomic, strong) NSString *value;

@end
