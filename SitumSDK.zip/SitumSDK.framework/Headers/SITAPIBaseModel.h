//
//  SITAPIBaseModel.h
//  SitumSDK
//
//  Created by A Barros on 29/3/16.
//  Copyright © 2016 Situm. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SITAPIBaseModel : NSObject

@property (nonatomic, strong) NSDate *createdAt;
@property (nonatomic, strong) NSDate *updatedAt;


@end
