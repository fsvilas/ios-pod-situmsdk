//
//  SITEvent.h
//  SitumSDK
//
//  Created by A Barros on 22/9/15.
//  Copyright (c) 2015 Situm. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "SITCircularArea.h"

#import "SITRectangularArea.h"

/**
 An event: POI with radius, conversion area and asociated statistics. It is intended for usage in marketing apps
 */
@interface SITEvent : NSObject

#pragma mark - Properties

/**
 *  This is a unique identifier of each event
 */
@property (nonatomic, strong) NSNumber *identifier;

/**
 *  Name
 */
@property (nonatomic, strong) NSString *name;

/**
 Date containing the time when a resource was first created.
 */
@property (nonatomic, strong) NSDate *createdAt;

/**
 Date containing the time when a resource was last updated.
 */
@property (nonatomic, strong) NSDate *updatedAt;

/**
 *  Additional information about the SITEvent
 */
@property (nonatomic, strong) NSString *info;

/**
 *  Link to a website displaying relating info about the event
 */
@property (nonatomic, strong) NSString *url;

/**
 *  The area inside the SITIndoorBuilding where the event should be fired.
 */
@property (nonatomic, strong) SITCircularArea *trigger;

/**
 *  The area inside the SITIndoorBuilding where the event should be considered as converted
 */
@property (nonatomic, strong) SITCircularArea *conversion;

/**
 * Custom fields that can be added from the Dashboard
 */
@property (nonatomic, strong) NSDictionary<NSString*, NSString*> *customFields;

#pragma mark - Deprecated

/// :nodoc:
@property (nonatomic, strong) NSNumber *project_identifier __attribute__((deprecated("Deprecated, use trigger.center.buildingIdentifier")));

/// :nodoc:
@property (nonatomic, strong) SITRectangularArea *conversionArea __attribute__((deprecated("Deprecated, use conversion instead")));

@end
