//
//  SITCartesianCoordinate.h
//  SitumSDK
//
//  Created by A Barros on 21/2/17.
//  Copyright © 2017 Situm. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 Type used to represent the x or y axis value of a cartesian coordinate in meters under a reference frame 
 */
typedef double SITCartesianMeters;

/**
 A structure that contains cartesian coordinate.
 */
@interface SITCartesianCoordinate : NSObject

#pragma mark - Initializers

/**
 Create a cartesian coordinate
 @param x Coordinate at x-axis
 @param y Coordinate at y-axis
 @return `SITCartesianCoordinate`
 */
- (instancetype)initWithX:(SITCartesianMeters)x
                        y:(SITCartesianMeters)y;

/**
 Create a cartesian coordinate
 @param x Coordinate at x-axis
 @param y Coordinate at y-axis
 @return `SITCartesianCoordinate`
 */
+ (instancetype)coordinateWithX:(SITCartesianMeters)x
                              y:(SITCartesianMeters)y;

#pragma mark - Properties

/**
 Coordinate at x-axis
 */
@property (nonatomic) SITCartesianMeters x;

/**
 Coordinate at x-axis
 */
@property (nonatomic) SITCartesianMeters y;

@end
