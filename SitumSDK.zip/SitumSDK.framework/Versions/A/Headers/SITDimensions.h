//
//  SITDimensions.h
//  SitumSDK
//
//  Created by A Barros on 2/3/17.
//  Copyright © 2017 Situm. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "SITCartesianCoordinate.h"

/**
 Define 2D dimensions of a rectangular area.
 */
@interface SITDimensions : NSObject

#pragma mark - Initializers

/**
 Initializer
 
 @param width Width in meters
 @param height Height in meters
 */
- (instancetype)initWithWidth:(SITCartesianMeters)width
                       height:(SITCartesianMeters)height;

#pragma mark - Properties

/// Width in meters
@property (nonatomic, readonly) SITCartesianMeters width;

/// height in meters
@property (nonatomic, readonly) SITCartesianMeters height;



@end
