//
//  SITCoordinateConverter.h
//  SitumSDK
//
//  Created by A Barros on 2/3/17.
//  Copyright © 2017 Situm. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "SITAngle.h"
#import "SITLocation.h"
#import "SITPoint.h"
#import "SITDimensions.h"
#import "SITBounds.h"

/**
 Utility class to convert between cartesian coordinates and geographical coordinates.
 */
@interface SITCoordinateConverter : NSObject

#pragma mark - Initializers

/**
 Initializer
 
 @param dimensions Dimensions of the building
 @param center Center of the building
 @param rotation Rotation of the building
 
 @return `SITCoordinateConverter`
 */
- (instancetype)initWithDimensions:(SITDimensions *)dimensions
                            center:(CLLocationCoordinate2D)center
                          rotation:(SITAngle *)rotation;

#pragma mark - Methods

/**
 Dimensions of cartesian area, in meters
 @return `SITDimensions`
 */
- (SITDimensions*) getDimensions;

/**
 Convert geographic coordinate to cartesian coordinate
 @return `SITCartesianCoordinate`
 */
- (SITCartesianCoordinate *)toCartesianCoordinate:(CLLocationCoordinate2D)coordinate;

/**
 Convert cartesian coordinate to geographic coordinate
 @return `CLLocationCoordinate2D`
 */
- (CLLocationCoordinate2D)toLocationCoordinate:(SITCartesianCoordinate *)cartesianCoordinate;

/**
 Converts an angle from building coordinate system to Earth coordinate system.
 @return `SITAngle`
 */
- (SITAngle *)toAngle:(SITAngle *)cartesianAngle;

/**
 Converts an angle from Earth coordinate system to building coordinate system.
 @return `SITAngle`
 */
- (SITAngle *)toCartesianAngle:(SITAngle *)angle;

/**
 Building bounds
 */
- (SITBounds)bounds;

/**
 Rotated bounds
 */
- (SITBounds)rotatedBounds;

/// :nodoc:
- (SITAngle*) convertBearingToCartesianAngle: (SITAngle*) bearing;

@end
