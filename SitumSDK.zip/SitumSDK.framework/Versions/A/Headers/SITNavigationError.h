//
//  SITNavigationError.h
//  SitumSDK
//
//  Created by A Barros on 27/2/17.
//  Copyright © 2017 Situm. All rights reserved.
//

#ifndef SITNavigationError_h
#define SITNavigationError_h

/// :nodoc:
extern NSString *const kSITNavigationErrorDomain;

/// Type of error the navigation manager can return.
typedef NS_ENUM(NSInteger, SITNavigationError) {
    /// Network error
    kSITNavigationErrorNetwork = 0,
    /// You have not permissions access the information because you are not allowed to see it.
    kSITNavigationErrorUnauthorized,
    /// There is a problem with one or more parameters.
    kSITNavigationErrorBadRequest,
};

#endif /* SITNavigationError_h */
