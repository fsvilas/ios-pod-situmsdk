//
//  SITOccurrence.h
//  SitumSDK
//
//  Created by A Barros on 29/3/16.
//  Copyright © 2016 Situm. All rights reserved.
//

#import "SITAPIBaseModel.h"

/// Action of an event
typedef NS_ENUM(NSInteger, kSITOccurrenceAction)
{
    /// An event has been seen
    kSITOccurrenceViewed = 0,
    
    /// An event has been seen
    kSITOccurrenceClicked,
    
    /// An event has been converted
    kSITOccurrenceConverted,
};

/**
 *  Describes importante situations around events
 */
@interface SITOccurrence : SITAPIBaseModel

#pragma mark - Properties

/**
 *  Unique identifier of the ocurrence (this property can be nil if it's not created)
 */
@property (nonatomic, strong) NSNumber *identifier;

/**
 * Many to One relationship. Event in which the occurrence happended.
 */
@property (nonatomic, strong) NSNumber *eventIdentifier;

/**
 *  Identifier of the device
 */
@property (nonatomic, strong) NSNumber *deviceIdentifier;

/**
 *  The time when an event has been opened for more info
 */
@property (nonatomic, strong) NSDate *clickedAt;

/**
 *  The time when a user entered the conversion area of an event.
 */
@property (nonatomic, strong) NSDate *convertedAt;

@end
