//
//  SITRealTimeError.h
//  SitumSDK
//
//  Created by A Barros on 8/6/17.
//  Copyright © 2017 Situm. All rights reserved.
//

#ifndef SITRealTimeError_h
#define SITRealTimeError_h

/// :nodoc:
extern NSString *const kSITRealTimeErrorDomain;


/**
 Type of error the real time manager can return.
 */
typedef NS_ENUM(NSInteger, SITRealTimeError) {
    /**
     An invalid request was provided
     */
    kSITRealTimeErrorBadRequest = 0,
    /**
     The identifier of the building cannot be found on the account
     */
    kSITRealTimeErrorUnableToFindBuilding,
};


#endif /* SITRealTimeError_h */
