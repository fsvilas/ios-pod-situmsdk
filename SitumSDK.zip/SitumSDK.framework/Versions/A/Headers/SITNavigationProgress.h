//
//  SITNavigationProgress.h
//  SitumSDK
//
//  Created by A Barros on 21/2/17.
//  Copyright © 2017 Situm. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AvailabilityMacros.h>

#import "SITIndication.h"
#import "SITPoint.h"
#import "SITRouteStep.h"
#import "SITLocation.h"
#import "SITRouteSegment.h"


/**
 It provides information of the progress of a user while following a route.
 */
@interface SITNavigationProgress : NSObject

#pragma mark - Properties

/**
 Unique identifier of the step inside a route.
 */
@property (nonatomic) NSInteger currentStepIndex;

/**
 Distance from from point to end of step.
 */
@property (nonatomic) float distanceToEndStep;

/**
 Time from from point to end of route.
 */
@property (nonatomic) float timeToEndStep;

/**
 Distance from from point to end of route.
 */
@property (nonatomic) float distanceToGoal;

/**
 Time estimation from from point to end of step.
 */
@property (nonatomic) float timeToGoal;

/**
 Closest location inside the route closer to the user's location.
 */
@property (nonatomic, strong) SITLocation *closestLocationInRoute;

/**
 The indication a user should follow in order to arrive the destination following a route.
 */
@property (nonatomic, strong) SITIndication *currentIndication;

/**
 The next indication a user should follow in order to arrive the destination following a route.
 */
@property (nonatomic, strong) SITIndication *nextIndication;

/**
 Distance in meters to the closest point in route
 */
@property (nonatomic) float distanceToClosestPointInRoute;

/**
 Current route step
 */
@property (nonatomic, strong) SITRouteStep *routeStep;

/**
 List of ordered points of the route.
 */
@property (nonatomic, strong, nonnull) NSArray<SITPoint*>* points;

#pragma mark - Methods

/**
 Return list of ordered points split by floor, each list contains points from one floor, but can have multiple lists of the same floor.
 Use this method to display segments in a map, each list should be a polyline. For example, if there is no path to go to the other side
 of the same floor and you need to go up one floor and then go down again to the original floor, this method will return one segment on
 the current floor, one segment on the upper floor and one more segment in the current floor.
 Drawing example: if you want to draw all the points of a floor, you should draw a polyline for each list that contains the floor you want
 to show.
 
 @return Return list of ordered points split by floor.
 */
- (nonnull NSArray<SITRouteSegment*>*) segments;

#pragma mark - Deprecated

/**
 Closest point inside the route closer to the user's location.
 */
@property (nonatomic, strong) SITPoint *closestPointToRoute __attribute__((deprecated("Use closestLocationInRoute.position instead")));

@end
