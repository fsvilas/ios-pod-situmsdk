//
//  SITFloorResource.h
//  SitumSDK
//
//  Created by A Barros on 2/3/17.
//  Copyright © 2017 Situm. All rights reserved.
//

#import "SITBuildingResource.h"

/**
 A floor resource with building identifier and floor identifier
 */
@interface SITFloorResource : SITBuildingResource

#pragma mark - Properties

/**
 Unique identifier of the floor related with this resource
 */
@property (nonatomic, strong) NSString *floorIdentifier;

@end
