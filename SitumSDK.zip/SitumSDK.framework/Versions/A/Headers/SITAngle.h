//
//  SITAngle.h
//  SitumSDK
//
//  Created by A Barros on 2/3/17.
//  Copyright © 2017 Situm. All rights reserved.
//

#import <Foundation/Foundation.h>
/**
 Representation of an angle.
 */
@interface SITAngle : NSObject

#pragma mark - Initializers

/**
 * @param radians angle in radians, increasing in counter-clockwise
 */
- (instancetype)initWithRadians:(float)radians;

/**
 * @param degrees angle in degrees, increasing in counter-clockwise
 */
- (instancetype)initWithDegrees:(float)degrees;

#pragma mark - Methods

/**
 * @return angle in degrees, increasing in counter-clockwise
 */
- (float)degrees;

/**
 * @return angle in radians, increasing in counter-clockwise
 */
- (float)radians;

/**
 * @return angle in radians, increasing in clockwise
 */
- (float)degressClockwise;

/**
 * @return angle in radians in range (-pi,pi)
 */
- (float)radiansMinusPiPi;

@end
