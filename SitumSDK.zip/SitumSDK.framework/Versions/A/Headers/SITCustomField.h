//
//  SITPOICustomField.h
//  SitumSDK
//
//  Created by A Barros on 10/6/16.
//  Copyright © 2016 Situm. All rights reserved.
//

#import <Foundation/Foundation.h>
/**
 A Key-value structure to store information
 */
@interface SITCustomField : NSObject

#pragma mark - Properties

/**
 Key
 */
@property (nonatomic, strong) NSString *key;

/**
 Value
 */
@property (nonatomic, strong) NSString *value;

@end
