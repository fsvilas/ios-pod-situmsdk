//
//  SITBounds.h
//  SitumSDK
//
//  Created by A Barros on 9/3/17.
//  Copyright © 2017 Situm. All rights reserved.
//

#ifndef SITBounds_h
#define SITBounds_h

#import <CoreLocation/CoreLocation.h>

/**
 SITBounds represents a rectangular box containing the geographic coordinates of the corners of the region
 */
struct SITBounds {
    /** coordinate of the south-west corner of the bound.*/
    CLLocationCoordinate2D southWest;
    /** coordinate of the south-east corner of the bound.*/
    CLLocationCoordinate2D southEast;
    /** coordinate of the north-east corner of the bound.*/
    CLLocationCoordinate2D northEast;
    /** coordinate of the north-west corner of the bound.*/
    CLLocationCoordinate2D northWest;
};

/**
 SITBounds represents a rectangular box containing the geographic coordinates of the corners of the region
 */
typedef struct SITBounds SITBounds;

#endif /* SITBounds_h */
