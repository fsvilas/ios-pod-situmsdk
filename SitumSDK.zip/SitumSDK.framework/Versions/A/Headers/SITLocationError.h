//
//  SITLocationError.h
//  SitumSDK
//
//  Created by A Barros on 27/2/17.
//  Copyright © 2017 Situm. All rights reserved.
//

#ifndef SITLocationError_h
#define SITLocationError_h

/// :nodoc:
extern NSString *const kSITLocationErrorDomain;


/**
 Type of error the location manager can return.
 */
typedef NS_ENUM(NSInteger, SITLocationError) {
    /// there was a network error.
    kSITLocationErrorNetwork = 0,
    /// you have not permissions access the information because you are not allowed to see it.
    kSITLocationErrorUnauthorized,
    /// there is a problem with parameters.
    kSITLocationErrorBadRequest,
    /// you have no permissions to use the location of the user.
    kSITLocationErrorPermissionDenied,
    /// you can only start the system once.
    kSITLocationErrorAlreadyStarted,
    /// you can only stop the system when is previosly started.
    kSITLocationErrorSystemStopped,
    /// bluetooth is turned off
    kSITLocationErrorBluetoothIsOff,
    /// bluetooth permission is not granted
    kSITLocationErrorBluetoothUnauthorized,
    /// location services are disabled
    kSITLocationErrorLocationDisabled,
    /// location permission is not granted
    kSITLocationErrorLocationRestricted,
    /// permission to use location services has not been granted or rejected yet
    kSITLocationErrorLocationAuthStatusNotDetermined,
    /// model couldn't be processed (error in download, unzip or file moves)
    kSITLocationErrorBuildingModelNotAvaliable,
    /// building has no model, it needs to be calibrated first
    kSITLocationErrorBuildingNotCalibrated
};


#endif /* SITLocationError_h */
