//
//  SITIndoorLevel.h
//  SitumSDK
//
//  Created by Abraham on 3/3/15.
//  Copyright (c) 2015 Situm. All rights reserved.
//

#ifndef SITIndoorLevel_h
#define SITIndoorLevel_h

#import <Foundation/Foundation.h>

/**
 *  This class describes the properties from a level of a building.
 *  @note You should not create objects of this class. Instead you should retrieve them using the
 *  appropiate method of the SITCommunicationManager class.
 */

__deprecated_msg("Use SITFloor instead.")
@interface SITIndoorLevel : NSObject;


/**
 Unique identifier of the level
 */
@property (nonatomic, strong) NSNumber *identifier __attribute__((deprecated("Use identifier value of a SITFloor object instead.")));


/**
 Identifier of the Building this level belongs to
 */
@property (nonatomic, strong) NSNumber *project_identifier __attribute__((deprecated("Use buildingIdentifier value of a SITFloor object instead.")));


/**
 *  Number
 */
@property (nonatomic, strong) NSNumber *level __attribute__((deprecated("Use level value of a SITFloor object instead.")));
/**
 *  Name
 */
@property (nonatomic, strong) NSString *name __attribute__((deprecated("Information not publicly available. Use level property of a SITFloor object.")));;
/**
 *  Details
 */
@property (nonatomic, strong) NSString *detail __attribute__((deprecated("Information not publicly available. The SDK will handle this information internally for you.")));;

/**
 *  Scale of the map image (px/meter)
 */
@property (nonatomic, strong) NSNumber *scale __attribute__((deprecated("Use scale value of a SITFloor object instead.")));

@property (nonatomic, strong) NSString *map_url __attribute__((deprecated("Use mapURL value of a SITFloor object instead.")));

@property (nonatomic, strong) NSString *server_map_url __attribute__((deprecated("Information not publicly available. The SDK will handle this information internally for you.")));

/**
 *  Convinient method to create a string with the numeric information of the level property
 *
 *  @return String with the numeric information of the level property
 */
- (NSString *)shortName;

@end
#endif
