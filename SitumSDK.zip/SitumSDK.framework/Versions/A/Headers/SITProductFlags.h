//
//  SITProductFlags.h
//  SitumSDK
//
//  Created by A Barros on 7/7/16.
//  Copyright © 2016 Situm. All rights reserved.
//

#ifndef SITProductFlags_h
#define SITProductFlags_h

#define SITUM_PRODUCT 1

#define SITUM_PROTOBUF 1

#endif /* SITProductFlags_h */
