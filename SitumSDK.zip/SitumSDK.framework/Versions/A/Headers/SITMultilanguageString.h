//
//  SITMultilanguageString.h
//  SitumSDK
//
//  Created by A Barros on 2/3/17.
//  Copyright © 2017 Situm. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 * A string with a different value depending of the language.
 * ISO 639-2 is used to identify the languages.
 *
 * @see `ISO3Language`
 */
@interface SITMultilanguageString : NSObject

#pragma mark - Initializers

/**
 * This method initializes the object and sets the default locale for the localized string.
 * Right now only english and spanish are supported. If a different locale is passed to this method,
 * english will be set as default.
 *
 * @param defaultLocale A valid NSLocale object to be set as the default locale. (Only english and spanish supported as default)
 * @return Initialized instance of SITMultilanguageString with the default locale set.
 */
- (instancetype) initWithDefaultLocale: (NSLocale*) defaultLocale;

#pragma mark - Methods

/**
 * Obtain the value corresponding to the default locale.
 *
 * @return An string containing the value of the string for the default locale.
 */
- (NSString *) value;

/**
 * Obtain the value corresponding to the selected locale.
 *
 * @param locale A valid NSLocale object to be used to obtain the string value.
 * @return An string containing the value of the string for the selected locale.
 */
- (NSString *) valueForLocale: (NSLocale *) locale;

/**
 * Get the locale set as default. (Only english and spanish supported as default)
 *
 * @return A locale representing the default locale selected.
 */
- (NSLocale *) defaultLocale;

/**
 * Get the locales contained in this object.
 *
 * @return An array containing all avaliable locales for the string.
 */
- (NSArray *) locales;

/**
 * This method sets the default locale for the localized string. Right now only english and spanish
 * are supported. If a different locale is passed to this method, english will be set as default.
 *
 * @param locale A valid NSLocale object to be set as the default locale. (Only english and spanish supported as default)
 */
- (void) setDefaultLocale:(NSLocale *)locale;

/**
 * This method sets a new value and locale for the localized string.
 * Right now only english and spanish are supported. If a different locale is passed to this method,
 * english will be set as default.
 *
 * @param string String with the value associated to the selected locale.
 * @param locale A valid NSLocale object to be set with the associated string.
 */
- (void) setValue: (NSString *) string
        forLocale: (NSLocale *) locale;


#pragma mark - Deprecated

/**
 * This method initializes the object and sets the default value and locale for the localized string.
 * Right now only english and spanish are supported. If a different locale is passed to this method,
 * english will be set as default.
 *
 * @param value String with the value associated to the selected default locale.
 * @param defaultLocale A valid NSLocale object to be set as the default locale. (Only english and spanish supported as default)
 * @return Initialized instance of SITMultilanguageString with the default locale set.
 */
- (instancetype)initWithValue: (NSString *) value
                defaultLocale: (NSLocale *) defaultLocale __attribute__((deprecated("This constructor is deprecated. Please use initWithDefaultLocale: and set the string values with setValue:withLocale:")));



@end
