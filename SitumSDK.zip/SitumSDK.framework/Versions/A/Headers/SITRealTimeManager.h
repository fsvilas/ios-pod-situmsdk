//
//  SITRealTimeManager.h
//  SitumSDK
//
//  Created by A Barros on 7/6/17.
//  Copyright © 2017 Situm. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "SITRealTimeInterface.h"

/**
 Central point for accessing the location of the users in real time
 */
@interface SITRealTimeManager : NSObject <SITRealTimeInterface>

#pragma mark - Initializers

/**
 Call this method to receive a reference to an initialized object of this class

 @return shared manager object
 @note You should not try to initialized multiple objects of this class using alloc:init
 */
+ (instancetype)sharedManager;

#pragma mark - Properties

/**
 Delegate property to receive callbacks
 */
@property(nonatomic, assign) id <SITRealTimeDelegate> delegate;

#pragma mark - Methods

/**
 Rate at which information will be refreshed (in seconds)
 
 @note Check SITRealTimeRequest to know minimun and maximum values of this parameter
 */
- (NSInteger)updateInterval;

@end
