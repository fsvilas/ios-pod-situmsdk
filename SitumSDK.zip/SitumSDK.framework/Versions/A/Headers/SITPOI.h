//
//  SITPOI.h
//  SitumSDK
//
//  Created by Abraham on 9/3/15.
//  Copyright (c) 2015 Situm. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "SITPOIBase.h"
#import "SITIndoorPoint.h"

#import "SITPoint.h"

#import "SITBuildingResource.h"

#import "SITPOICategory.h"

/**
 *  This class represents a Point Of Interest inside a `SITBuilding`
 *  @see See SITPOIBase to check base properties
 */
@interface SITPOI : SITBuildingResource

#pragma mark - Properties

/**
 *  radius (m) of the cylindrical area of the POI around the (x,y) point
 */
@property (nonatomic, strong) NSNumber *radius;

/**
 *  Name
 */
@property (nonatomic, strong) NSString *name;

/**
 *  Additional information about the POI in HTML format
 */
@property (nonatomic, strong) NSString *infoHTML;

/**
 Unique identifier of the category of this poi
 */
@property (nonatomic, strong) NSString *categoryIdentifier;

/**
 *  Relationship to a SITPOICategory object
 */
@property (nonatomic, strong) SITPOICategory *category;

#pragma mark - Methods

/**
 Describes the location of the Point of interest (geographical and cartesianCoordinates)
 */
- (SITPoint *)position;

#pragma mark - Deprecated

/// :nodoc:
@property (nonatomic, strong) NSNumber *level_identifier __attribute__((deprecated("Use position.floorIdentifier instead")));

/// :nodoc:
@property (nonatomic, strong) NSNumber *project_identifier __attribute__((deprecated("Use buildingIdentifier property of the SITResource base class instead")));

/// :nodoc:
@property (nonatomic, strong) NSNumber *x __attribute__((deprecated("Use position.cartesianCoordinate.x instead")));

/// :nodoc:
@property (nonatomic, strong) NSNumber *y __attribute__((deprecated("Use position.cartesianCoordinate.y instead")));

/// :nodoc:
@property (nonatomic, strong) NSNumber *sergasID __attribute__((deprecated("Use customFields of the SITResource base class instead")));

/// :nodoc:
@property (nonatomic) BOOL hasShifts __attribute__((deprecated("Use customFields of the SITResource base class instead")));

/// :nodoc:
- (SITIndoorPoint *)indoorPoint __attribute__((deprecated("Use position instead")));

/// :nodoc:
@property (nonatomic, strong) NSString *info __attribute__((deprecated("Use infoHTML instead")));

@end
