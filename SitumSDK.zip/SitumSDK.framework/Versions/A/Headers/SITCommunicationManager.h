//
//  SITCommunicationManager.h
//  SitumSDK
//
//  Created by Abraham on 6/3/15.
//  Copyright (c) 2015 Situm. All rights reserved.
//

#ifndef SITCommunicationManager_h
#define SITCommunicationManager_h


#import <Foundation/Foundation.h>

#import "SITCommunicationInterface.h"
#import "SITCommunicationConstants.h"

#import "SITFloor.h"
#import "SITBuilding.h"

/**
 The Communication manager allows you to make asynchronous requests to the server, mostly to fetch data.
 */
@interface SITCommunicationManager : NSObject

#pragma mark - Initializers

/**
 *  Call this method to receive a reference to an initialized object of this class
 *
 *  @return The shared manager object. Initially, this method stablish a value of 24 hours as the CAHCE_MAX_AGE for the cache system.
 *  @note You should not try to initialize multiple objects of this class using alloc:init because it would result in unexpected behaviour.
 */
+ (instancetype)sharedManager;

#pragma mark - Methods

/**
 *  Retrieve the time when data on cache was retrieved
 *
 *  @return the date when the information was successfully fetched or nil if there is not cache.
 */
- (NSDate *)cacheDate;

/**
 *  Establish the time when the stored data on cache expires
 *
 *  @param cacheMaxAge Integer value in seconds. If a negative value is inserted, a value of 0 will be established.
 */
- (void)setCacheMaxAge:(NSInteger)cacheMaxAge;

/**
 *  Retrieve the value when the stored data on cache expires.
 *
 *  @return Integer value in seconds.
 */
- (NSInteger)cacheMaxAge;

/**
 *  Clear the contents of the cache for a particular user
 */
- (void)clearCache;

/**
 *  Retrieve the information of the available categories
 *
 *  @param options              additional parameters to customize the internal operation of the method declared in SITCommunicationConstants.h
 *  @param completion           the kind of block that will be performed after the operation has been completed
 *  @return BOOL value indicating if the operation will be performed or not
 *  @note Valid options for this method are: SITForceRequestKey. The value of this key is a NSNumber with a bool value on it. The value of YES means that the request will be directed to the network system directly without checking the cache system. The value of NO means the request will be directed to the cache system and if not found it will be redirected to the network system.
 */
- (BOOL)fetchCategoriesWithOptions:(NSDictionary *)options
                    withCompletion:(SITPOICategoriesFetchHandler)completion;


/**
 Retrieve the list of floors associated with a building

 @param buildingIdentifier unique identifier of the building
 @param options parameters that modify the internal behaviour
 @param success the kind of block that will be executed when the operation has successfully been performed
 @param failure the kind of block that will be executed when the operation fails
 @return error that describes why the operation could not be executed (a nil value means the request is valid and will be executed)
 @note Keys of the options dictionary: forceRequest boolean value that determines if the operation should hit the server (YES) or the cachesystem (NO)
 */
- (NSError *)fetchFloorsForBuilding:(NSString *)buildingIdentifier
                        withOptions:(NSDictionary *)options
                            success:(SITSuccessHandler)success
                            failure:(SITFailureCompletion)failure;

/**
 Retrieve the list of users positioning in the building
 @param buildingIdentifier unique identifier of the building
 @param options parameters that modify the internal behaviour
 @param success the kind of block that will be executed when the operation has successfully been performed
 @param failure the kind of block that will be executed when the operation fails
 @return error that describes why the operation could not be executed (a nil value means the request is valid and will be executed)
 @note Keys of the options dictionary: forceRequest boolean value that determines if the operation should hit the server (YES) or the cachesystem (NO)
 */
- (NSError *)fetchRealTimeUsersForBuilding:(NSString *)buildingIdentifier
                               withOptions:(NSDictionary *)options
                                   success:(SITSuccessHandler)success
                                   failure:(SITFailureCompletion)failure;

/**
 Retrieve the list of buildings

 @param options parameters that modify the internal behaviour
 @param success the kind of block that will be executed when the operation has successfully been performed. Information can be accessed through the results key on the mapping result dictionary
 @param failure the kind of block that will be executed when the operation fails with an error describing what has failed
 @return error that describes why the operation could not be executed (a nil value means the request is valid and will be executed)
 @note Keys of the options dictionary: forceRequest boolean value that determines if the operation should hit the server (YES) or the cachesystem (NO)
 */
- (NSError *)fetchBuildingsWithOptions:(NSDictionary *)options
                               success:(SITSuccessHandler)success
                               failure:(SITFailureCompletion)failure;


/**
 Retrieve the list of indoor points of interest associated with a building

 @param buildingIdentifier unique identifier of the building
 @param options parameters that modify the internal behaviour (see discussion section)
 @param success the kind of block that will be executed when the operation has successfully been performed. Information can be accessed through the results key on the mapping result dictionary
 @param failure the kind of block that will be executed when the operation fails with an error describing what has failed
 @return error that describes why the operation could not be executed (a nil value means the request is valid and will be executed)
 @note Keys of the options dictionary: forceRequest boolean value that determines if the operation should hit the server (YES) or the cachesystem (NO)
 */
- (NSError *)fetchPoisOfBuilding:(NSString *)buildingIdentifier
                     withOptions:(NSDictionary *)options
                         success:(SITSuccessHandler)success
                         failure:(SITFailureCompletion)failure;

/**
 Retrieve the list of outdoor points of interest associated with a building

 @param buildingIdentifier unique identifier of the building
 @param options parameters that modify the internal behaviour (see discussion section)
 @param success the kind of block that will be executed when the operation has successfully been performed. Information can be accessed through the results key on the mapping result dictionary
 @param failure the kind of block that will be executed when the operation fails with an error describing what has failed
 @return error that describes why the operation could not be executed (a nil value means the request is valid and will be executed)
 @note Keys of the options dictionary: forceRequest boolean value that determines if the operation should hit the server (YES) or the cachesystem (NO)
 */
- (NSError *)fetchOutdoorPoisOfBuilding:(NSString *)buildingIdentifier
                            withOptions:(NSDictionary *)options
                                success:(SITSuccessHandler)success
                                failure:(SITFailureCompletion)failure;


/**
 Retrieve the information of a building.

 @param buildingIdentifier unique identifier of the building.
 @param options parameters that modify the internal behaviour (see discussion section)
 @param success the kind of block that will be executed when the operation has successfully been performed. Information can be accessed through the results key on the mapping result dictionary
 @param failure failure the kind of block that will be executed when the operation fails with an error describing what has failed
 @return error that describes why the operation could not be executed (a nil value means the request is valid and will be executed)
 @note Keys of the options dictionary: forceRequest boolean value that determines if the operation should hit the server (YES) or the cachesystem (NO)
 */
- (NSError *)fetchBuildingInfo:(NSString *)buildingIdentifier
                   withOptions:(NSDictionary *)options
                       success:(SITSuccessHandler)success
                       failure:(SITFailureCompletion)failure;


/**
 Retrieve the floorplan of a floor

 @param floor SITFloor object
 @param imageFetchHandler the kind of block that will be executed when the operation has successfully been performed (a nil data would mean the operation has failed)
 @return error that describes why the operation could not be executed (a nil value means the request is valid and will be executed)
 */
- (BOOL)fetchMapFromFloor:(SITFloor *)floor
           withCompletion:(SITImageFetchHandler)imageFetchHandler; // This should check cache first

/**
 * Retrieve the buildings you are allowed to see. This is an asynchronous operation.
 *
 * @param buildindFetchHandler buildindFetchHandler This is the block which will be called after the operation has been completed.
 * @param options              additional parameters to customize the internal operation of the method
 *
 * @return This method gives the user a flag that indicates if the operation has been performed (YES) or not (NO).
 * @note Valid options for this method are: SITForceRequestKey. The value of this key is a NSNumber with a bool value on it. The value of YES means that the request will be directed to the network system directly without checking the cache system. The value of NO means the request will be directed to the cache system and if not found it will be redirected to the network system.
 */
- (BOOL)fetchIndoorBuildingsWithOptions:(NSDictionary *)options
                         withCompletion:(SITBuildingFetchHandler)buildindFetchHandler;

/**
 *  Retrieve the contents of an icon of a category
 *
 *  @param selected   BOOL parameter indicating the kind of icon to retrieve (YES means the selected one, NO means the regular or normal one)
 *  @param category   SITPOICategory object. Normally you do not instantiate objects of this class, instead you should use the one obtained by -fetchCategoriesWithCompletion:
 *  @param completion the kind of callback that will be called after the operation has been completed
 *
 *  @return BOOL value indicating if the operation is well formed and if it will be executed (YES) or not (NO)
 */
- (BOOL)fetchSelected:(BOOL)selected
      iconForCategory:(SITPOICategory *)category
       withCompletion:(SITPOICategoryIconFetchCompletion)completion;

/**
 *  Retrieve the events of a SITBuilding
 *
 *  @param building           SITBuilding object
 *  @param options            additional parameters to customize the internal operation of the method
 *  @param completion         SITHandler
 *
 *  @return This method gives the user a flag that indicates if the operation has been performed or not.
 *  @note Valid options for this method are: SITForceRequestKey. The value of this key is a NSNumber with a bool value on it. The value of YES means that the request will be directed to the network system directly without checking the cache system. The value of NO means the request will be directed to the cache system and if not found it will be redirected to the network system.
 */
- (BOOL) fetchEventsFromBuilding:(SITBuilding *) building
                     withOptions:(NSDictionary *)options
                  withCompletion:(SITHandler (^)(NSArray<SITEvent*> *result, NSError *error))completion;

/**
 *  Retrieve the events of a SITBuilding
 *
 *  @param building           SITBuilding object
 *  @param completion         SITHandler
 *
 *  @return This method gives the user a flag that indicates if the operation has been performed or not.
 *  @note Valid options for this method are: SITForceRequestKey. The value of this key is a NSNumber with a bool value on it. The value of YES means that the request will be directed to the network system directly without checking the cache system. The value of NO means the request will be directed to the cache system and if not found it will be redirected to the network system.
 */
- (BOOL) fetchEventsFromBuilding:(SITBuilding *) building
                  withCompletion:(SITHandler (^)(NSArray<SITEvent*> *result, NSError *error))completion;

/**
 Notifies an event occurrence
 
 @param event The event that occurred
 @param successCompletion completion block that will be executed if the operation is performed
 @param errorCompletion completion block that will be executed if the operation fails
 @return BOOL Returns a flag that indicates if the operation has been performed or not.
 */
- (BOOL)createOccurrenceForEvent:(nonnull SITEvent *)event
                     withSuccess:(nonnull SITOccurrenceCompletion)successCompletion
                         failure:(nonnull SITErrorCompletion)errorCompletion;

/**
 Notifies an event occurrence
 
 @param occurrence event occurrence
 @param action action performed on the event
 @param successCompletion completion block that will be executed if the operation is performed
 @param errorCompletion completion block that will be executed if the operation fails
 @return BOOL Returns a flag that indicates if the operation has been performed or not.
 */
- (BOOL)updateOccurrence:(nonnull SITOccurrence *)occurrence
                forEvent:(kSITOccurrenceAction)action
             withSuccess:(nonnull SITOccurrenceCompletion)successCompletion
                 failure:(nonnull SITErrorCompletion)errorCompletion;
/**
 *  Authenticate with user and password
 *
 * @param user email of the user
 * @param password password of the user
 * @param loginHandler completion block that will be executed if the operation is performed
 * @return This method gives the user a flag that indicates if the operation has been performed (YES) or not (NO).
 * @note This method needs to be called before performing any other network operation in order to validate the credentials.
 *              Otherwise the operations could failed with a 401 error code.
 *  Before attempting to connect with different credentials remeber to disconnect to the actual session performing a -logoutWithCompletion: operation.
 */
- (BOOL)loginWithUser:(NSString *)user
             password:(NSString *)password
       withCompletion:(SITLoginHandler)loginHandler;

/**
 * Disconnect and clear previous session credentials
 *
 * @param logoutHandler completion block that will be executed if the operation if performed.
 * @return This method gives the user a flag that indicates if the operation has been performed (YES) or not (NO).
 */
- (BOOL)logoutWithCompletion:(SITLogoutHandler)logoutHandler;

#pragma mark - Deprecated methods

/// :nodoc:
- (BOOL)fetchCategoriesWithCompletion:(SITPOICategoriesFetchHandler)completion __deprecated_msg("Use - (BOOL)fetchCategoriesWithOptions:withCompletion:");

/// :nodoc:
- (BOOL)fetchIndoorBuildingsWithCompletion:(SITBuildingFetchHandler)buildindFetchHandler __attribute__((deprecated("Use - (BOOL)fetchCategoriesWithOptions:withCompletion:")));

/// :nodoc:
- (BOOL)fetchInfoOfIndoorBuilding: (SITIndoorBuilding *) indoorBuilding
                   withCompletion: (SITBuildingInfoFetchHandler) completion __attribute__((deprecated("Use fetchBuildingInfo instead")));

/// :nodoc:
- (BOOL)fetchInfoOfIndoorBuilding: (SITIndoorBuilding *) indoorBuilding
                      withOptions: (NSDictionary *) options
                   withCompletion: (SITBuildingInfoFetchHandler) completion __attribute__((deprecated("Use fetchBuildingInfo instead")));

/// :nodoc:
- (BOOL)fetchIndoorLevelsFromIndoorBuilding:(SITIndoorBuilding *)indoorBuilding
                             withCompletion:(SITIndoorLevelFetchHandler)indoorLevelFetchHandler __attribute__((deprecated("Use - (BOOL)fetchIndoorLevelsFromIndoorBuilding:withOptions:withCompletion:")));

/// :nodoc:
- (BOOL)fetchIndoorLevelsFromIndoorBuilding:(SITIndoorBuilding *)indoorBuilding
                                withOptions:(NSDictionary *)options
                             withCompletion:(SITIndoorLevelFetchHandler)indoorLevelFetchHandler __attribute__((deprecated("Use - fetchFloorsForBuilding:withOptions:success:failure instead")));


/// :nodoc:
- (BOOL)fetchIndoorLevelMapFromIndoorLevel:(SITIndoorLevel *)indoorLevel
                            withCompletion:(SITIndoorLevelMapFetchHandler)indoorLevelMapHandler __attribute__((deprecated("Use - fetchMapFromFloor:withCompletion: instead")));

/// :nodoc:
- (BOOL)fetchPOIsFromIndoorBuilding:(SITIndoorBuilding *)indoorBuilding
                     withCompletion:(SITPOIFetchHandler)POIFetchHandler __attribute__((deprecated("Use - (BOOL)fetchPOIsFromIndoorBuilding:withOptions:withCompletion:")));

/// :nodoc:
- (BOOL)fetchPOIsFromIndoorBuilding:(SITIndoorBuilding *)indoorBuilding
                        withOptions:(NSDictionary *)options
                     withCompletion:(SITPOIFetchHandler)POIFetchHandler __attribute__((deprecated("Use - (BOOL)fetchPoisOfBuilding:withOptions:success:failure:")));

/// :nodoc:
- (NSArray *)filterPOIs:(NSArray *)POIs
          byIndoorLevel:(SITIndoorLevel *)indoorLevel __attribute__((deprecated("Use - (NSArray *)filterPOIs:byCategory:byIndoorLevel")));

/// :nodoc:
- (NSArray *)filterPOIs:(NSArray *)POIs
             byCategory:(NSString *)category
          byIndoorLevel:(SITIndoorLevel *)indoorLevel __attribute__((deprecated("Deprecated method.")));

/// :nodoc:
- (BOOL)fetchExteriorPOIsFromIndoorBuilding:(SITIndoorBuilding *)indoorBuilding
                             withCompletion:(SITExteriorPOIFetchHandler)exteriorPOIFetchHandler __attribute__((deprecated("Use - (BOOL)fetchOutdoorPOIsFromIndoorBuilding:withOptions:withCompletion:")));

/// :nodoc:
- (BOOL)fetchOutdoorPOIsFromIndoorBuilding:(SITIndoorBuilding *)indoorBuilding
                               withOptions:(NSDictionary *)options
                            withCompletion:(SITExteriorPOIFetchHandler)exteriorPOIFetchHandler __attribute__((deprecated("Use fetchPoisOfBuilding instead.")));


/// :nodoc:
- (BOOL)fetchGraphFromIndoorBuilding:(SITIndoorBuilding *)indoorBuilding
                      withCompletion:(SITGraphFetchHandler)graphFetchHandler __attribute__((deprecated("Use - (BOOL)fetchGraphFromIndoorBuilding:withOptions:withCompletion:")));

/// :nodoc:
- (BOOL)fetchGraphFromIndoorBuilding:(SITIndoorBuilding *)indoorBuilding
                         withOptions:(NSDictionary *)options
                      withCompletion:(SITGraphFetchHandler)graphFetchHandler __attribute__((deprecated("Fetching the graph is no longer supported.")));

/// :nodoc:
- (BOOL)fetchEventsFromIndoorBuilding:(SITIndoorBuilding *)indoorBuilding
                       withCompletion:(SITEventsFetchHandler)eventsFetchHandler __attribute__((deprecated("Use - (BOOL)fetchEventsFromBuilding:withCompletion:")));


/// :nodoc:
- (BOOL)fetchEventsFromIndoorBuilding:(SITIndoorBuilding *)indoorBuilding
                          withOptions:(NSDictionary *)options
                       withCompletion:(SITEventsFetchHandler)eventsFetchHandler __attribute__((deprecated("Use - (BOOL)fetchEventsFromBuilding:withOptions:withCompletion:")));

#pragma mark - Events management. As a developer, you should not use this methods. They are for internal use only.

/// :nodoc:
- (BOOL)pushCalibrationsForFloorIdentifier:(NSInteger)indoorLevelIdentifier
                              filesAtPaths:(NSArray *)paths
                            withCompletion:(SITCalibrationsPushHandler)calibrationsPushHandler;

/// :nodoc:
- (BOOL)retrieveModelForBuilding:(nonnull SITIndoorBuilding *)building
                     withSuccess:(nonnull SITSuccessRetrievingModelCompletion)successCompletion
                         failure:(nonnull SITFailureCompletion)failureCompletion __attribute__((deprecated("Fetching the model is no longer supported.")));
@end

#endif
