//
//  SITDirectionsError.h
//  SitumSDK
//
//  Created by A Barros on 24/2/17.
//  Copyright © 2017 Situm. All rights reserved.
//

#ifndef SITDirectionsError_h
#define SITDirectionsError_h

/// :nodoc:
extern NSString *const kSITDirectionsErrorDomain;

/**
 Error of the directions module
 */
typedef NS_ENUM(NSInteger, SITDirectionsError) {
    /// A network error
    kSITDirectionsErrorNetwork = 0,
    
    /// The user is not allowed to use that information
    kSITDirectionsErrorUnauthorized,
    
    /// Parameters are invalid
    kSITDirectionsErrorBadRequest,
};

#endif /* SITDirectionsError_h */
