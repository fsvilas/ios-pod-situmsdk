//
//  SITLocation.h
//  SitumSDK
//
//  Created by A Barros on 21/2/17.
//  Copyright © 2017 Situm. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "SITPoint.h"
#import "SITAngle.h"


/**
 The quality of the location. Is only used indoor.
 */
typedef NS_ENUM(NSInteger, kSITQualityValues)
{
    /// The quality of the location is low.
    kSITLow = 0,
    /// The quality of the location is high.
    kSITHigh,
};

/**
 Describes a geographical position of the user, either indoor or outdoor.
 A valid indoor location has floorIdentifier and cartesianCoordinate in its position property.
 */
@interface SITLocation : NSObject

#pragma mark - Initializers

/**
 Constructor.
 
 @param timestamp since 1970 when the location was determined, in milliseconds
 @param position geographical coordinate information.
 @param bearing the direction in which the device is traveling in geographical coordinate system (degrees)
 @param cartesianBearing The direction in which the device is traveling in cartesian coordinate system (radians)
 @param quality indicative of quality calculated with accuracy and building size.
 @param accuracy ccuracy radius (in meters).
 @param provider multiple providers can create locations. Determines which one has determined the location.
 @return initialized location
 */
- (instancetype)initWithTimestamp:(NSTimeInterval)timestamp
                         position:(SITPoint *)position
                          bearing:(float)bearing // Need to be degrees
                 cartesianBearing:(float)cartesianBearing // Need to be radians
                          quality:(kSITQualityValues)quality
                         accuracy:(float)accuracy
                         provider:(NSString *)provider;

/**
 Constructor.
 
 @param timestamp since 1970 when the location was determined, in milliseconds
 @param position geographical coordinate information.
 @param bearing the direction in which the device is traveling in geographical coordinate system (degrees)
 @param cartesianBearing The direction in which the device is traveling in cartesian coordinate system (radians)
 @param quality indicative of quality calculated with accuracy and building size.
 @param bearingQuality indication of the quality of the bearing value
 @param accuracy ccuracy radius (in meters).
 @param provider multiple providers can create locations. Determines which one has determined the location.
 @return initialized location
 */
- (instancetype)initWithTimestamp:(NSTimeInterval)timestamp
                         position:(SITPoint *)position
                          bearing:(float)bearing // Need to be degrees
                 cartesianBearing:(float)cartesianBearing // Need to be radians
                          quality:(kSITQualityValues)quality
                   bearingQuality:(kSITQualityValues)bearingQuality
                         accuracy:(float)accuracy
                         provider:(NSString *)provider;

#pragma mark - Properties

/**
 The time interval since 1970 at which this location was determined, expressed in milliseconds
 */
@property (nonatomic) NSTimeInterval timestamp;


/**
 Geographical coordinate information.
 */
@property (nonatomic, strong) SITPoint *position;


/**
 The direction in which the device is traveling in geographical coordinate system (can be directly applied to a map provider)
 */
@property (nonatomic, strong) SITAngle *bearing;


/**
 The direction in which the device is traveling in cartesian coordinate system.
 */
@property (nonatomic, strong) SITAngle *cartesianBearing;

/**
 Indication of the quality of the bearing value
 @note kSITHigh means the system is very confident on the bearing values. kSITLow means the system is still trying to determine the correct bearing; this situation happens when initializing the system.
 */
@property (nonatomic) kSITQualityValues bearingQuality;

/**
 Return an indicative of quality calculated with accuracy and building size.
 @note Only used in indoor.
 */
@property (nonatomic) kSITQualityValues quality;


/**
 Return the accuracy radius (in meters).
 */
@property (nonatomic) float accuracy;


/**
 Multiple providers can create locations.
 This property determines which one has determined the location.
 */
@property (nonatomic, strong) NSString *provider;

/**
 Identifier of the device that has generated the location
 */
@property (nonatomic, strong) NSString *deviceId;

#pragma mark - Methods

/**
 Method that determines if the location has a high-quality bearing
 
 @return BOOL Location bearinqQuality is high (YES) or not (NO)
 */
- (BOOL)hasBearing;

@end
