//
//  SITAccessibilityMode.h
//  SitumSDK
//
//  Created by Cristina Sánchez Barreiro on 20/11/2018.
//  Copyright © 2018 Situm. All rights reserved.
//

#ifndef SITAccessibilityMode_h
#define SITAccessibilityMode_h

/**
 * @typedef SITAccessibilityMode
 *
 * A list of accessibility modes that can be chosen when computing a route.
 */
typedef NS_ENUM(int, SITAccessibilityMode) {
    /**
     * The route should choose the best route, without taking into account if it is accessible ot not
     */
    kSITChooseShortest = 0,
    /**
     * The route should always use accessible nodes
     */
    kSITOnlyAccessible = 1,
    /**
     * The route should never use accessible floor changes
     */
    kSITOnlyNotAccessibleFloorChanges = 2,
};

#endif /* SITAccessibility_h */
