//
//  SITBuildingInfo.h
//  SitumSDK
//
//  Created by A Barros on 13/3/17.
//  Copyright © 2017 Situm. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "SITBuilding.h"
#import "SITFloor.h"
#import "SITPOI.h"
#import "SITEvent.h"
/**
  A building and its dependencies: floors, POIs and events
 */
@interface SITBuildingInfo : NSObject

#pragma mark - Properties

/**
 Building, without its dependencies
 */
@property (nonatomic, strong) SITBuilding *building;

/**
 Array containing the floors of the building. See `SITFloor` for more info
 */
@property (nonatomic, strong) NSArray<SITFloor *> *floors;

/**
 Array containing the indoor POIs of the building. See `SITPOI` for more info
 */
@property (nonatomic, strong) NSArray<SITPOI *> *indoorPois;

/**
 Array containing the outdoor POIs of the building. See `SITPOI` for more info
 */
@property (nonatomic, strong) NSArray<SITPOI *> *outdoorPois;

/**
 Array containing the events of the building. See `SITEvent` for more info
 */
@property (nonatomic, strong) NSArray<SITEvent *> *events;

@end
