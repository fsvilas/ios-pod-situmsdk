//
//  SITLocationRequest.h
//  SitumSDK
//
//  Created by A Barros on 27/2/17.
//  Copyright © 2017 Situm. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "SITBeaconFilter.h"

/// :nodoc:
typedef NS_ENUM(int, SITLocationPriority){

    kSITHighAccuracy = 0,
    
    kSITBalancedPowerAccuracy,
    
    kSITLowPower
} __attribute__((deprecated("Deprecated")));

/**
 * The interval indicating how often positions will be uploaded to realtime
 */
typedef NS_ENUM(NSInteger, SITRealtimeUpdateInterval) {
    ///The realtime dashboard will update in real time.
    kSITUpdateIntervalRealtime = 1,
    /// The realtime dashboard will update faster, but not in real time.
    kSITUpdateIntervalFast = 5,
    /// A compromise between real time and low power consumption
    kSITUpdateIntervalNormal = 15,
    /// The realtime will update slower.
    kSITUpdateIntervalSlow = 25,
    /// It will save a lot more battery but locations won't be shown in the real time.
    kSITUpdateIntervalBatterySaver = 1800
};

/**
 A data object that contains parameters for the location service (SITLocationManager)
 */
@interface SITLocationRequest : NSObject <NSCopying> 

#pragma mark - Initializers

/**
 Constructor.
 
 @param buildingId Unique identifier of the building in which you want to locate a user.
 
 @return Initialized SITLocationRequest object.
 */
- (instancetype) initWithBuildingId: (NSString*) buildingId;

#pragma mark - Properties

/**
 The time interval indicating how often the position should be uploaded to realtime.
 */
@property (nonatomic, readonly) SITRealtimeUpdateInterval realtimeUpdateInterval;


/**
 * Set if you want to use dead reckoning to get fast position updates using only the inertial sensors,
 * between the server position updates. This parameter is incompatible with interval. If interval is
 * set, dead reckoning will be deactivated for this request.
 */
@property (nonatomic, readwrite) BOOL useDeadReckoning;


/**
 * Set if you want to use Gps for positioning indoor.
 */
@property (nonatomic, readwrite) BOOL useGps;


/**
 Unique identifier of the building in which you want to locate a user. (This property is mandatory).
 */
@property (nonatomic, strong) NSString *buildingID;


/**
 The thread where the location updates will be provided. If not provided, the main thread will be used.
 */
@property (nonatomic, strong) NSOperationQueue *operationQueue;


/**
 Additional options to modify the internal operation of the Location provider (private usage only).
 */
@property (nonatomic, strong) NSDictionary *options;

/**
 Custom UUIDs. The system will scan beacons with those uuids
 */
@property (nonatomic, strong) NSArray<SITBeaconFilter *> *beaconFilters;

/**
 Set the desired interval for location updates, in milliseconds. This interval is inexact, the service will try to keep this rate in a "best effort" way.
 This parameter is incompatible with dead reckoning. If set, dead reckoning will be deactivated for this request.
 */
@property (nonatomic) int interval;

/**
 Minimum displacement between location updates
 */
@property (nonatomic) float smallestDisplacement;

/**
 Set if you want to use barometer data for positioning.
 */
@property (nonatomic, readwrite) BOOL useBarometer;

#pragma mark - Methods

/**
Setter. This parameter is incompatible with interval. If interval is set, dead reckoning will be deactivated for this request.
 
 @param useDeadReckoning Boolean value indicating if deadReckoning should be used.
 */
- (void) setUseDeadReckoning: (BOOL) useDeadReckoning;

/**
 Setter.
 
 @param useGps Boolean value indicating if gps positioning should be used.
 */
- (void) setUseGps: (BOOL) useGps;

/**
 Setter.
 
 @param realtimeUpdateInterval SITRealtimeUpdateInterval value indicating how often the position should be upload to realtime.
 */
- (void) setRealtimeUpdateInterval: (SITRealtimeUpdateInterval) realtimeUpdateInterval;

/**
 Setter. This parameter is incompatible with dead reckoning. If set, dead reckoning will be deactivated for this request.
 
 @param interval Integer value (in milliseconds) with the desired time interval for location updates.
 */
- (void) setInterval: (int) interval;

/**
 Setter. This parameter is incompatible with dead reckoning. If set, dead reckoning will be deactivated for this request.
 
 Keep in mind that if you set a custom value for {@link #interval(int)} you may
 not receive updates at the desired interval if the other condition isn't met.
 
 If this value is set the Dead Reckoning will be disabled
 
 @param smallestDisplacement Float value (in meters) with the minimum displacement between location updates.
 */
- (void) setSmallestDisplacement: (float) displacement;

/**
 Setter.
 
 @param useBarometer Boolean value indicating if barometer should be used for positioning.
 */
- (void) setUseBarometer: (BOOL) useBarometer;


/**
 Check if the request is valid.

 @return BOOL value that indicates if the request is valid (YES) or not (NO).
 */
- (BOOL)isValid;

#pragma mark - Deprecated

/// :nodoc:
typedef NS_ENUM(int, SITLocationProvider){
    /**
     *  Localization can use the best provider available at any given moment (default).
     */
    kSITHybridProvider = 0,
    
    /**
     *  Use only cloud provider.
     */
    kSITCloudProvider,
    
    /**
     Use only phone provider. (coming soon).
     */
    kSITInPhoneProvider
};

/**
 One of SITLocationProvider.
 */
@property (nonatomic, readwrite) SITLocationProvider provider __attribute__((deprecated("Location provider is no longer selectable. Provider will always be kSITInPhoneProvider")));


/**
 The time interval indicating how often the position should be uploaded to realtime. Deprecated, use realtimeUpdateInterval instead.
 */
@property (nonatomic, readwrite) NSInteger updateInterval __attribute__((deprecated("Use realtimeUpdateInterval instead")));

/// :nodoc:
@property (nonatomic, readwrite) SITLocationPriority priority __attribute__((deprecated("Deprecated")));

/**
 Setter.
 
 @param updateInterval Integer value indicating how often the position should be upload to realtime. Deprecated, use setRealtimeUpdateInterval instead.
 */
- (void) setUpdateInterval: (NSInteger) updateInterval __attribute__((deprecated("Use setRealtimeUpdateInterval instead")));

/**
 Constructor.
 
 @param priority one of SITLocationPriority
 @param provider one of SITLocationProvider
 @param updateInterval The time interval at which location will be uploaded to realtime
 @param buildingID unique identifier of the building in which you want to locate a user. (This property is mandatory).
 @param operationQueue the thread where the location updates will be provided. If not provided, the main thread will be used.
 @param options additional options to modify the internal operation of the Location provider (private usage only).
 @return initialized object.
 */
- (instancetype)initWithPriority:(SITLocationPriority)priority
                        provider:(SITLocationProvider)provider
                  updateInterval:(NSInteger)updateInterval
                      buildingID:(NSString *)buildingID
                  operationQueue:(NSOperationQueue *)operationQueue
                         options:(NSDictionary *)options __attribute__((deprecated("Use base constructor instead")));

/**
 Constructor.
 
 @param priority one of SITLocationPriority
 @param provider one of SITLocationProvider
 @param updateInterval The time interval at which location will be uploaded to realtime
 @param buildingID unique identifier of the building in which you want to locate a user. (This property is mandatory).
 @param operationQueue the thread where the location updates will be provided. If not provided, the main thread will be used.
 @param useDeadReckoning determines if dead reckoning should be used
 @param options additional options to modify the internal operation of the Location provider (private usage only).
 @return initialized object.
 */
- (instancetype)initWithPriority:(SITLocationPriority)priority
                        provider:(SITLocationProvider)provider
                  updateInterval:(NSInteger)updateInterval
                      buildingID:(NSString *)buildingID
                  operationQueue:(NSOperationQueue *)operationQueue
                useDeadReckoning:(BOOL)useDeadReckoning
                         options:(NSDictionary *)options __attribute__((deprecated("Use base constructor instead")));

@end
