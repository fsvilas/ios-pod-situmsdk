//
//  SITLocationManager.h
//  SitumSDK
//
//  Created by A Barros on 27/2/17.
//  Copyright © 2017 Situm. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "SITLocationInterface.h"
#import "SITLocationError.h"


/**
 SITLocationManager
 The SITLocationManager class is the central point for configuring the delivery of location- and headind
 related events to your app. You use the shared instance of this class to establish the parameters that determine when
 location and heading events should be delivered and to start and stop the actual delivery of those events.
 
 Set delegate to listen for location updates.
 
 @note This class needs bluetooth information to do its work. In case bluetooth access is off, or permissions are
 denied, an error will be returned to the delegate. It can be thrown at the initial checking or at any moment during the
 positioning.
 */
@interface SITLocationManager : NSObject <SITLocationInterface>

#pragma mark - Initializers

/**
 Singleton instance
 
 @return An initialized object
 @note You should always use this method to obtain the manager object and should not try to create instances directly
 */
+ (instancetype)sharedInstance;

#pragma mark - Methods
/**
 Object that conforms to the SITLocationDelegate Protocol
 */
@property (nonatomic, weak) id<SITLocationDelegate> delegate;

/// :nodoc:
- (void) updateFromDeadReckoningWithX: (float) x
                                    y: (float) y
                                  yaw: (float) yaw;


@end
