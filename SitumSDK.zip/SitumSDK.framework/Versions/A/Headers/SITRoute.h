//
//  SITRoute.h
//  SitumSDK
//
//  Created by A Barros on 21/2/17.
//  Copyright © 2017 Situm. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SITRouteSegment.h"
#import "SITRouteStep.h"
#import "SITIndication.h"


/**
 Route between two points. From and destination must be inside the same building.
 */
@interface SITRoute : NSObject

#pragma mark - Initializers

/**
 Constructor.
 
 @param origin from point.
 @param destination destination point.
 @param routeSteps steps to arrive from origin to destination.
 @param indications indications the user should follow to arrive from origin to destination.
 @param distance distance of the whole route
 @param options additional information of the route.
 @return initialized object.
 @note You should not use this method. Instead you should user the route objects provided by SITDirectionsManager.
 */
- (instancetype)initWithOrigin:(SITPoint *)origin
                   destination:(SITPoint *)destination
                    routeSteps:(NSArray *)routeSteps
                   indications:(NSArray *)indications
                      distance:(float)distance
                       options:(NSDictionary *)options;

#pragma mark - Properties

/**
 The initial point of the route.
 */
@property (nonatomic, readonly) SITPoint *origin;

/**
 The destination point of the route.
 */
@property (nonatomic, readonly) SITPoint *destination;

/**
 Parameters associated with the request. 
 Use accessible key to see if the route has been
 */
@property (nonatomic, readonly) NSDictionary *options;

/**
 Steps of the route to arrive from origin to destination.
 */
@property (nonatomic, strong, readonly) NSArray *routeSteps;

/**
 Indications to follow.
 */
@property (nonatomic, strong, readonly) NSArray *indications;

/**
 Returns list of ordered points of the route.
 */
@property (nonatomic, strong, readonly, nonnull) NSArray<SITPoint*>* points;

#pragma mark - Methods

/**
 Retrieve the indication for a particular step of the route.

 @param step step inside the route
 @return indication associated with the step (if valid step).
 */
- (SITIndication *)indicationForStep:(SITRouteStep *)step;

/**
 Retrieve the next indication for a particular step of the route.
 
 @param step step inside the route
 @return next indication associated with the step (if valid step).
 */
- (SITIndication *)indicationForNextStep:(SITRouteStep *)step;

/**
 Complete distance of the route.

 @return distance of the route (meters).
 */
- (float)distance;


/**
 Estimated time of the route.

 @return time to the goal (seconds)
 */
- (float)timeToGoal;

/**
 Return list of ordered points split by floor, each list contains points from one floor, but can have multiple lists of the same floor.
 Use this method to display segments in a map, each list should be a polyline. For example, if there is no path to go to the other side
 of the same floor and you need to go up one floor and then go down again to the original floor, this method will return one segment on
 the current floor, one segment on the upper floor and one more segment in the current floor.
 Drawing example: if you want to draw all the points of a floor, you should draw a polyline for each list that contains the floor you want
 to show.
 
 @return Return list of ordered points split by floor.
 */
- (nonnull NSArray<SITRouteSegment*>*) segments;

@end
