//
//  SITRouteSegment.h
//  SitumSDK
//
//  Created by Adrián Rodríguez on 21/03/2019.
//  Copyright © 2019 Situm. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SITPoint.h"

/**
 * A continuous segment of a route that contains points of the same floor
 */
@interface SITRouteSegment : NSObject

#pragma mark - Initializers
/**
 * Constructor
 *
 * @param floorIdentifier String containing the floor identifier for all of the points in this segment
 * @param points Array containing all the points included in this segment
 *
 * @return Initialized instance of the "SITRouteSegment" object
 */
- (instancetype) initWithFloorIdentifier: (nonnull NSString*) floorIdentifier
                              withPoints: (nonnull NSArray<SITPoint*>*) points;

#pragma mark - Properties

/**
 * An string containing the floor identifier for all of the points in this segment
 */
@property (nonatomic, strong, nonnull) NSString* floorIdentifier;

/**
 * Return the points of the segment
 */
@property (nonatomic, strong, nonnull) NSArray<SITPoint*>* points;

@end
