//
//  SITURL.h
//  SitumSDK
//
//  Created by A Barros on 2/3/17.
//  Copyright © 2017 Situm. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 Abstraction of URL. Unifies management of both absolutes and relatives URLs.
*/
@interface SITURL : NSObject

#pragma mark - Initializers

/**
 Initializer
 
 @param direction The URL
 @note Accepts both absolute and relative URLs
 @return `SITURL`
 */
- (instancetype)initWithDirection:(NSString *)direction;

#pragma mark - Properties

/**
 True if the value used to construct the URL doesn't start by '/', meaning it has a specific host.
 */
@property (nonatomic, readonly) BOOL isAbsolute;

/**
 The URL
 */
@property (nonatomic, readonly) NSString *direction;



@end
